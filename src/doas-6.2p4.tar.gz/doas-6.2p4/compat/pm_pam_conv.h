#include <security/pam_appl.h>

int pam_tty_conv(int num_msg, struct pam_message **mess,
    struct pam_response **resp, void *my_data);

